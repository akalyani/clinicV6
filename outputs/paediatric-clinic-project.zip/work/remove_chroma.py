from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

source = Path('/Users/amitkalyani/.codex/generated_images/01a02c9b-23e0-7371-8f5e-8879402a5384/exec-c3e99b8f-8ae2-4edc-b0da-eecd49bfc559.png')
output = Path('work/hero-family-transparent.png')

image = Image.open(source).convert('RGBA')
pixels = np.asarray(image).copy()
red, green, blue = (pixels[:, :, index].astype(np.int16) for index in range(3))

# The generated background is a pure green screen.  Fade out green pixels while
# retaining the anti-aliased subject edges.
green_dominance = green - np.maximum(red, blue)
alpha = np.clip((175 - green_dominance) * 3, 0, 255).astype(np.uint8)
alpha[(green > 170) & (red < 90) & (blue < 90)] = 0

alpha_image = Image.fromarray(alpha, 'L').filter(ImageFilter.GaussianBlur(0.45))
image.putalpha(alpha_image)
image.save(output)
