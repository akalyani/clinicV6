from pathlib import Path
from collections import deque

import numpy as np
from PIL import Image, ImageFilter

source = Path('/Users/amitkalyani/.codex/generated_images/01a02c9b-23e0-7371-8f5e-8879402a5384/exec-a458a682-828a-48a6-ae9a-b2246c5895f1.png')
output = Path('work/hero-family-transparent.png')

image = Image.open(source).convert('RGB')
pixels = np.asarray(image)
brightest = pixels.max(axis=2)
darkest = pixels.min(axis=2)

# The generated preview uses a neutral, very-light checkerboard backdrop.
# Keep coloured or shaded illustration pixels, then grow the mask slightly
# to retain the clean white clinic coat at its natural edges.
foreground = ((brightest - darkest) > 14) | (brightest < 232)
for _ in range(10):
    foreground = np.maximum.reduce([
        foreground,
        np.roll(foreground, 1, axis=0), np.roll(foreground, -1, axis=0),
        np.roll(foreground, 1, axis=1), np.roll(foreground, -1, axis=1),
        np.roll(np.roll(foreground, 1, axis=0), 1, axis=1),
        np.roll(np.roll(foreground, 1, axis=0), -1, axis=1),
        np.roll(np.roll(foreground, -1, axis=0), 1, axis=1),
        np.roll(np.roll(foreground, -1, axis=0), -1, axis=1),
    ])

# Keep light coat areas that are surrounded by the illustrated subjects.
# Only transparent regions connected to an outer image edge remain background.
background = ~foreground
visited = np.zeros(background.shape, dtype=bool)
queue = deque()
height, width = background.shape
for x in range(width):
    if background[0, x]: queue.append((0, x)); visited[0, x] = True
    if background[height - 1, x] and not visited[height - 1, x]: queue.append((height - 1, x)); visited[height - 1, x] = True
for y in range(height):
    if background[y, 0] and not visited[y, 0]: queue.append((y, 0)); visited[y, 0] = True
    if background[y, width - 1] and not visited[y, width - 1]: queue.append((y, width - 1)); visited[y, width - 1] = True
while queue:
    y, x = queue.popleft()
    for ny, nx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
        if 0 <= ny < height and 0 <= nx < width and background[ny, nx] and not visited[ny, nx]:
            visited[ny, nx] = True
            queue.append((ny, nx))
foreground |= background & ~visited

alpha = Image.fromarray((foreground * 255).astype(np.uint8), mode='L').filter(ImageFilter.GaussianBlur(1.1))
result = image.convert('RGBA')
result.putalpha(alpha)
result.save(output)
