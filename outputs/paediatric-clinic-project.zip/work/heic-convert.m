#import <Foundation/Foundation.h>
#import <ImageIO/ImageIO.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        if (argc != 3) return 2;
        NSURL *input = [NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[1]]];
        NSURL *output = [NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[2]]];
        CGImageSourceRef source = CGImageSourceCreateWithURL((__bridge CFURLRef)input, NULL);
        if (!source) return 1;
        CGImageRef image = CGImageSourceCreateImageAtIndex(source, 0, NULL);
        CFRelease(source);
        if (!image) return 1;
        CGImageDestinationRef destination = CGImageDestinationCreateWithURL((__bridge CFURLRef)output, CFSTR("public.jpeg"), 1, NULL);
        if (!destination) { CGImageRelease(image); return 1; }
        NSDictionary *options = @{(__bridge NSString *)kCGImageDestinationLossyCompressionQuality: @0.9};
        CGImageDestinationAddImage(destination, image, (__bridge CFDictionaryRef)options);
        bool completed = CGImageDestinationFinalize(destination);
        CFRelease(destination);
        CGImageRelease(image);
        return completed ? 0 : 1;
    }
}
