import Foundation
import ImageIO
import UniformTypeIdentifiers

guard CommandLine.arguments.count == 3 else {
    fputs("Usage: heic-convert.swift <input> <output>\n", stderr)
    exit(2)
}

let input = URL(fileURLWithPath: CommandLine.arguments[1])
let output = URL(fileURLWithPath: CommandLine.arguments[2])

guard let source = CGImageSourceCreateWithURL(input as CFURL, nil),
      let image = CGImageSourceCreateImageAtIndex(source, 0, nil),
      let destination = CGImageDestinationCreateWithURL(
          output as CFURL,
          UTType.jpeg.identifier as CFString,
          1,
          nil
      ) else {
    fputs("Unable to decode \(input.path)\n", stderr)
    exit(1)
}

CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.9] as CFDictionary)

guard CGImageDestinationFinalize(destination) else {
    fputs("Unable to write \(output.path)\n", stderr)
    exit(1)
}
